<?php
/**
 * @package  Asia Home Shops
 */
namespace App\Base;

defined( 'ABSPATH' ) || exit;

class TemplatesCustom
{
	public function __construct()
    {
    }
}